from distutils.core import setup

setup(name='clar',
      version='0.1dev',
      description='Concomitant Lasso with Repetitions',
      author='Anonymous',
      packages=['clar'],
      )
