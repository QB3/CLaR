import seaborn as sns


list_pb_name = ["CLaR", "SGCL", "MLER", "MLE", "MRCER", "MTL"]
list_pb_name.reverse()
labels = ["CLaR", "SGCL", "$\ell_{2,1}$-MLER", "$\ell_{2,1}$-MLE", "$\ell_{2,1}$-MRCER", "MTL"]

current_palette = sns.color_palette("colorblind")
dict_color = {}
dict_color["CLaR"] = current_palette[2]
dict_color["SGCL"] = current_palette[2]
dict_color["MTLME"] = current_palette[1]
dict_color["MTL"] = current_palette[1]
dict_color["MLE"] = current_palette[0]
dict_color["MLER"] = current_palette[0]
dict_color["MRCER"] = current_palette[3]
dict_color["MRCE"] = current_palette[2]

dict_label_plot = {}
dict_label_plot["CLaR"] = "CLaR"
dict_label_plot["SGCL"] = "SGCL"
dict_label_plot["MTLME"] = "MTLR"
dict_label_plot["MTL"] = "MTL"
dict_label_plot["MLER"] = "MLER"
dict_label_plot["MLE"] = "MLE"
dict_label_plot["MRCER"] = "MRCER"
dict_label_plot["MRCE"] = "MRCE"

dict_markers = {}
dict_markers["CLaR"] = '>'
dict_markers["MTLME"] = '>'
dict_markers["MLER"] = '>'
dict_markers["MRCER"] = '>'
dict_markers["SGCL"] = 's'
dict_markers["MTL"] = 's'
dict_markers["MLE"] = 's'
dict_markers["MRCE"] = 's'
