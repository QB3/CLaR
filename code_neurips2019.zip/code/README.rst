CLaR
=====

This package implements the CLaR alorithm, a fast algorithm to handle sparse linear regression with heteroscedastic noise.

It also implements a variation of the MRCE algorithm with a L21 penalization on the regression coefficient Beta, and which takes into account the repetitions.
Rothman, A. J., Levina, E., & Zhu, J. (2010). Sparse multivariate regression with covariance estimation.

To reproduce the results we propose you 2 installations:
- light (<2G) to play with the roc curves on synthetic data, but you will not see brains
- full but long (20min, 2.7G of packages + 1G of data), you will need a fast internet connection, but you will be able to play with brain plots

BE CAREFUL: if you choose the full installation process, You need to have a fast internet connection:
1- to download all the packages
2- to download the real data


Light install
=====
To be able to run the experiments  you should install the conda environment:

```bash
conda env create -f light_environment.yml
conda activate light-clar-env```
(you may need to open  fresh new terminal)

To be able to run the code you first need to run, in this folder (code folder):
```pip install -e .```

You should now be able to run a friendly example:
```ipython -i examples/synthetic_data.py```


Full install
=====

```bash
conda env create -f full_environment.yml
conda activate full-clar-env
pip install -e .```

You should now be able to run a friendly example:
```bash
ipython -i examples/real_data.py
```

You are now able to play with the estimators:
comment and uncomment the name of the optimization problem to solve.
For instance you can comment the line ```pb_name = "CLaR"```.
And uncomment ```pb_name = "MTL"```


Reproduce all experiments
=====
Scripts for roc curves (synthetic and realistic experiments) need a lot of computing power
as the results for a lot of algorithms have to be computed on a whole path.
Servers with multiple CPUs are preferable for these experiments.
However scripts on real data run faster (<15sec by algorithm).

All the figures of the paper can be reproduced.
What is needed is in the code/expes file.
- synthetic experiments are in code/expes/expe3
    do ```bash
    cd expes/expe3
    run main_expe3.py
    ```
- realistic experiments are in code/expes/expe4
    do ```bash
    cd expes/expe3
    run main_expe4.py```
- real experiments are in code/expes/expe7
    do ```bash
    cd expes/expe3
    run main_expe7.py
    ```
